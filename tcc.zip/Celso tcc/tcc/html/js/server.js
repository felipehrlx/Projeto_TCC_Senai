const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();

app.use(cors());
app.use(express.json());

// =========================
// CONEXÃO MONGODB
// =========================
mongoose.connect("mongodb://127.0.0.1:27017/foodplm_saas");

// =========================
// MODELOS
// =========================
const UserSchema = new mongoose.Schema({
    email: String,
    password: String
});

const ReportSchema = new mongoose.Schema({
    userId: String,
    nome: String,
    tipo: String,
    periodo: String,
    dataInicial: String,
    dataFinal: String,
    campos: [String],
    downloads: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model("User", UserSchema);
const Report = mongoose.model("Report", ReportSchema);

// =========================
// AUTH JWT
// =========================
const SECRET = "foodplm_secret";

// =========================
// REGISTER
// =========================
app.post("/register", async (req, res) => {
    const hashed = await bcrypt.hash(req.body.password, 10);

    const user = await User.create({
        email: req.body.email,
        password: hashed
    });

    res.json(user);
});

// =========================
// LOGIN
// =========================
app.post("/login", async (req, res) => {
    const user = await User.findOne({ email: req.body.email });

    if (!user) return res.status(400).json({ error: "User not found" });

    const ok = await bcrypt.compare(req.body.password, user.password);

    if (!ok) return res.status(400).json({ error: "Invalid password" });

    const token = jwt.sign({ id: user._id }, SECRET);

    res.json({ token });
});

// =========================
// MIDDLEWARE AUTH
// =========================
function auth(req, res, next) {
    const token = req.headers.authorization;

    if (!token) return res.status(401).json({ error: "No token" });

    try {
        const decoded = jwt.verify(token, SECRET);
        req.userId = decoded.id;
        next();
    } catch {
        res.status(401).json({ error: "Invalid token" });
    }
}

// =========================
// CREATE REPORT
// =========================
app.post("/reports", auth, async (req, res) => {
    const report = await Report.create({
        userId: req.userId,
        ...req.body
    });

    res.json(report);
});

// =========================
// GET REPORTS
// =========================
app.get("/reports", auth, async (req, res) => {
    const reports = await Report.find({ userId: req.userId }).sort({ createdAt: -1 });
    res.json(reports);
});

// =========================
// DELETE REPORT
// =========================
app.delete("/reports/:id", auth, async (req, res) => {
    await Report.deleteOne({ _id: req.params.id, userId: req.userId });
    res.json({ ok: true });
});

// =========================
// DOWNLOAD COUNT
// =========================
app.post("/reports/:id/download", auth, async (req, res) => {
    await Report.updateOne(
        { _id: req.params.id },
        { $inc: { downloads: 1 } }
    );

    res.json({ ok: true });
});

// =========================
app.listen(3000, () => console.log("API running on port 3000"));