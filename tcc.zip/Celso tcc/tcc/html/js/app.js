const API = "http://localhost:3000";

let token = localStorage.getItem("token");

// =========================
// LOGIN SIMPLES (EXEMPLO)
// =========================
async function login(email, password) {
    const res = await fetch(`${API}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    token = data.token;

    localStorage.setItem("token", token);
}

// =========================
// BUSCAR RELATÓRIOS
// =========================
async function loadReports() {
    const res = await fetch(`${API}/reports`, {
        headers: { Authorization: token }
    });

    return await res.json();
}

// =========================
// CRIAR RELATÓRIO
// =========================
async function createReport(data) {
    await fetch(`${API}/reports`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: token
        },
        body: JSON.stringify(data)
    });
}

// =========================
// DELETAR
// =========================
async function deleteReport(id) {
    await fetch(`${API}/reports/${id}`, {
        method: "DELETE",
        headers: { Authorization: token }
    });
}

// =========================
// DOWNLOAD COUNT
// =========================
async function markDownload(id) {
    await fetch(`${API}/reports/${id}/download`, {
        method: "POST",
        headers: { Authorization: token }
    });
}