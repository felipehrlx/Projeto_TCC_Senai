let demandas = [];



function adicionarDemanda(){

    const nome = document.getElementById("nomeProduto").value;

    const categoria = document.getElementById("categoriaProduto").value;

    const descricao = document.getElementById("descricaoProduto").value;

    const responsavel = document.getElementById("responsavelProduto").value;

    const prioridade = document.getElementById("prioridadeProduto").value;


    if(nome==""){

        alert("Digite o nome");

        return;
    }


    demandas.push({

        id:Date.now(),

        nome,

        categoria,

        descricao,

        responsavel,

        prioridade,

        status:"Pendente",

        data:new Date().toLocaleDateString("pt-BR")

    });


    renderizarDemandas();

    limparFormulario();

}



function renderizarDemandas(){

    const lista = document.getElementById("listaDemandas");

    lista.innerHTML = "";


    demandas.forEach(item=>{


        let cor = "badge-warning";


        if(item.status=="Aprovado")

            cor="badge-success";


        if(item.status=="Rejeitado")

            cor="badge-danger";



        lista.innerHTML += `

        <div class="item-demanda"

        onclick="mostrarDetalhes(${item.id})">


            <div class="item-top">

                <h3>${item.nome}</h3>

                <span class="badge ${cor}">

                    ${item.status}

                </span>

            </div>


            <p>${item.categoria}</p>

            <small>

            ${item.responsavel}

            </small>

        </div>

        `;

    });

}



function mostrarDetalhes(id){

    const d = demandas.find(x=>x.id===id);


    document.getElementById("detalhesProduto").innerHTML = `

    <div class="detalhes-box">

        <h2>${d.nome}</h2>


        <div class="linha">

            <strong>Categoria:</strong>

            ${d.categoria}

        </div>


        <div class="linha">

            <strong>Descrição:</strong>

            ${d.descricao}

        </div>


        <div class="linha">

            <strong>Responsável:</strong>

            ${d.responsavel}

        </div>


        <div class="linha">

            <strong>Prioridade:</strong>

            ${d.prioridade}

        </div>


        <div class="linha">

            <strong>Status:</strong>

            ${d.status}

        </div>


        <button class="btn btn-success"

        onclick="aprovar(${d.id})">

        Aprovar

        </button>


        <button class="btn"

        style="background:#dc3545"

        onclick="reprovar(${d.id})">

        Reprovar

        </button>

    </div>

    `;

}




function aprovar(id){

    const item = demandas.find(d=>d.id===id);

    item.status="Aprovado";

    renderizarDemandas();

    mostrarDetalhes(id);

}



function reprovar(id){

    const item = demandas.find(d=>d.id===id);

    item.status="Rejeitado";

    renderizarDemandas();

    mostrarDetalhes(id);

}



function limparFormulario(){

    document.getElementById("nomeProduto").value="";

    document.getElementById("categoriaProduto").value="";

    document.getElementById("descricaoProduto").value="";

    document.getElementById("responsavelProduto").value="";

}

function excluir(id){

    const confirmar = confirm("Deseja realmente excluir esta demanda?");

    if(!confirmar) return;

    demandas = demandas.filter(d => d.id !== id);

    renderizarDemandas();

    document.getElementById("detalhesProduto").innerHTML =
    "Selecione uma demanda para visualizar.";
}