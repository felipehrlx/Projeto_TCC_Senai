// Aguarda o HTML carregar completamente antes de rodar o script
document.addEventListener("DOMContentLoaded", () => {
    
    // Seleciona os elementos que vamos manipular
    const loginForm = document.querySelector(".login-form");
    const loginBtn = document.querySelector(".btn-login");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    // Escuta o evento de "enviar" (submit) do formulário
    loginForm.addEventListener("submit", (event) => {
        // Trava o recarregamento padrão da página
        event.preventDefault();

        // Guarda o texto original do botão
        const textoOriginal = loginBtn.innerHTML;

        // Muda o visual do botão para indicar carregamento
        loginBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Autenticando...';
        loginBtn.style.opacity = "0.8";
        loginBtn.style.cursor = "not-allowed";
        loginBtn.disabled = true; // Impede que o usuário clique duas vezes

        // Simula um tempo de resposta de um servidor (1.5 segundos)
        setTimeout(() => {
            
            // Pega os valores que o usuário digitou (você usará isso no futuro com banco de dados)
            const emailDigitado = emailInput.value;
            const senhaDigitada = passwordInput.value;

            console.log("Tentativa de login com:", emailDigitado);

            // Redireciona o usuário para o Dashboard
            window.location.href = 'index.html';

        }, 1500); // 1500 milissegundos = 1.5 segundos
    });
});