document.addEventListener("DOMContentLoaded", () => {
    
    // Seleciona os elementos da página
    const recoveryForm = document.querySelector(".login-form");
    const recoveryBtn = document.querySelector(".btn-login");
    const emailInput = document.getElementById("email");

    // Escuta o envio do formulário
    recoveryForm.addEventListener("submit", (event) => {
        // Trava o envio padrão (refresh)
        event.preventDefault();

        // Muda o visual do botão para indicar processamento
        recoveryBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Enviando link...';
        recoveryBtn.style.opacity = "0.8";
        recoveryBtn.style.cursor = "not-allowed";
        recoveryBtn.disabled = true;

        // Simula o tempo do sistema processando e enviando o e-mail (1.5 segundos)
        setTimeout(() => {
            
            const emailDigitado = emailInput.value;
            console.log("Recuperação solicitada para o e-mail:", emailDigitado);

            // Mostra o aviso de sucesso para o usuário
            alert(`Tudo certo! Se o e-mail ${emailDigitado} estiver cadastrado, você receberá um link de recuperação em instantes.`);

            // Redireciona de volta para a tela de login
            window.location.href = 'login.html';

        }, 1500);
    });
});