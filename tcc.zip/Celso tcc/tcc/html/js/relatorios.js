document.addEventListener("DOMContentLoaded", () => {
    const btnGerar = document.querySelector(".btn-submit");
    const reportsList = document.querySelector(".reports-list");
    const summaryNumbers = document.querySelectorAll(".summary-number");

    let relatorios = JSON.parse(localStorage.getItem("relatorios")) || [];

    render();
    updateDashboard();

    // =========================
    // CRIAR RELATÓRIO
    // =========================
    btnGerar.addEventListener("click", () => {
        const data = getFormData();

        if (!data.campos.length) {
            alert("Selecione pelo menos um campo!");
            return;
        }

        const relatorio = {
            id: crypto.randomUUID(),
            nome: `Relatório de ${data.tipo}`,
            tipo: data.tipo,
            periodo: data.periodo,
            dataInicial: data.dataInicial,
            dataFinal: data.dataFinal,
            campos: data.campos,
            createdAt: new Date().toISOString(),
            downloads: 0
        };

        relatorios.unshift(relatorio);

        save();
        render();
        updateDashboard();

        alert("Relatório criado com sucesso!");
    });

    // =========================
    // PEGAR DADOS DO FORM
    // =========================
    function getFormData() {
        return {
            tipo: document.querySelectorAll("select")[0].value,
            periodo: document.querySelectorAll("select")[1].value,
            dataInicial: document.querySelectorAll("input[type='date']")[0].value,
            dataFinal: document.querySelectorAll("input[type='date']")[1].value,
            campos: [...document.querySelectorAll(".check-label input:checked")]
                .map(el => el.nextElementSibling.innerText)
        };
    }

    // =========================
    // RENDER LISTA
    // =========================
    function render() {
        reportsList.innerHTML = "";

        relatorios.forEach(r => {
            const item = document.createElement("div");
            item.className = "report-item";

            item.innerHTML = `
                <div class="report-item-info">
                    <div class="report-icon-wrapper">
                        <i class="far fa-file-alt"></i>
                    </div>
                    <div>
                        <h4 class="report-name">${r.nome}</h4>
                        <p class="report-meta">
                            ${r.tipo} • ${r.periodo} • ${r.dataInicial} até ${r.dataFinal}
                        </p>
                    </div>
                </div>

                <div class="report-item-actions">
                    <span class="report-date">${new Date(r.createdAt).toLocaleDateString()}</span>
                    <button class="btn btn-outline btn-sm download">Baixar</button>
                </div>
            `;

            item.querySelector(".download").addEventListener("click", () => {
                r.downloads++;
                save();
                updateDashboard();
                downloadCSV(r);
            });

            reportsList.appendChild(item);
        });
    }

    // =========================
    // DASHBOARD
    // =========================
    function updateDashboard() {
        const total = relatorios.length;

        const mesAtual = new Date().getMonth();

        const desteMes = relatorios.filter(r =>
            new Date(r.createdAt).getMonth() === mesAtual
        ).length;

        const downloads = relatorios.reduce((acc, r) => acc + (r.downloads || 0), 0);

        summaryNumbers[0].innerText = total;
        summaryNumbers[1].innerText = desteMes;
        summaryNumbers[2].innerText = "+25%";
        summaryNumbers[3].innerText = downloads;
    }

    // =========================
    // DOWNLOAD CSV
    // =========================
    function downloadCSV(r) {
        let csv = `Relatório: ${r.nome}\n\n`;
        csv += `Tipo,${r.tipo}\n`;
        csv += `Período,${r.periodo}\n`;
        csv += `Data Inicial,${r.dataInicial}\n`;
        csv += `Data Final,${r.dataFinal}\n\n`;

        csv += "Campos Selecionados\n";
        r.campos.forEach(c => csv += `${c}\n`);

        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = `${r.nome}.csv`;
        a.click();

        URL.revokeObjectURL(url);
    }

    // =========================
    // SALVAR LOCALSTORAGE
    // =========================
    function save() {
        localStorage.setItem("relatorios", JSON.stringify(relatorios));
    }
});